import { NextRequest, NextResponse } from "next/server";

const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzmE3uYzUty8s0c8zH_TiJkU5lTzUmYckVAahGEjlJjYKC5ORL2xMX0sM2BORB-_n5Ffg/exec"


export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    body.formType = "Newsletter";

    const res = await fetch(APPS_SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    const result = await res.json();
    if (result.success) return NextResponse.json({ success: true, message: "Subscribed" });
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  } catch {
    return NextResponse.json({ error: "Error" }, { status: 500 });
  }
}